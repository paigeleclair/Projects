﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2_Stocks // Defines the namespace for this code, grouping related classes and preventing naming conflicts.
{
    public partial class StartForm : Form // Declares a public partial class named StartForm, inheriting from the Form class for Windows Forms.
    {
        public StartForm() // Constructor for the StartForm class, initializes the form.
        // public StartForm(DateTime startDate, DateTime endDate) // Commented-out alternative constructor, potentially for initializing date pickers.
        {
            InitializeComponent(); // Initializes the form's components, as designed in the Visual Studio designer.
            //dateTimePicker_startDate.Value = startDate; // Commented-out line, potentially setting start date from the constructor.
            //dateTimePicker_endDate.Value = endDate; // Commented-out line, potentially setting end date from the constructor.

        }
        /// <summary>
        /// used to open the file dialog to selct a file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_load_Click(object sender, EventArgs e) // Event handler for the button_load's Click event.
        {
            openFileDialog_stockData.ShowDialog(); // Displays the open file dialog, allowing the user to select a file.
        }

        /// <summary>
        /// sets text of form to the filename, and since multiselect on files, for each file we create a new form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileDialog_stockData_FileOk(object sender, CancelEventArgs e) // Event handler for the open file dialog's FileOk event (triggered when a file is selected and "OK" is clicked).
        {
            Text = openFileDialog_stockData.FileNames[0]; // Sets the form's title to the first selected filename.
            foreach (string file in openFileDialog_stockData.FileNames) // Iterates through all selected files.
            {
                Form_Display fn = new Form_Display(file, dateTimePicker_startDate.Value, dateTimePicker_endDate.Value); // Creates a new Form_Display instance for each file, passing file path, start, and end dates.
                fn.Show(); // Displays the created Form_Display instance.
            }
            this.Hide(); // Hides the StartForm after displaying the Form_Display(s).
        }

        private void StartForm_Load(object sender, EventArgs e)
        {

        }
    }
}