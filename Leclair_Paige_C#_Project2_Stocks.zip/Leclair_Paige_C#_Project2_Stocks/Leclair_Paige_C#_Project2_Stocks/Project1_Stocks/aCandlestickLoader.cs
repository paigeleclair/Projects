﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2_Stocks //All code belongs to Project2_Stocks
{
    /// <summary>
    /// define a static class to load candlestick data from a CSV file
    /// </summary>
    public static class aCandlestickLoader // define a static class to load candlestick data from a CSV file
    {
        /// <summary>
        /// Loads candlestick data from a CSV file.
        /// </summary>
        /// <param name="filePath">The path of the CSV file to load.</param>
        /// <returns>A list of aCandlestick objects populated with data from the CSV.</returns>
        public static List<aCandlestick> LoadFromCsv(string filePath) // method to load data from CSV
        {
            var candlesticks = new List<aCandlestick>(); // initialize list for storing candlestick data

            using (var reader = new StreamReader(filePath)) // create StreamReader to read file at filePath
            {
                char[] delimiters = { '\\', ',', '"', ' ' }; // define delimiters for splitting CSV values

                string line = reader.ReadLine(); // read header line (first line) to skip it

                while ((line = reader.ReadLine()) != null) // read each line until end of file
                {
                    var values = line.Split(delimiters, StringSplitOptions.RemoveEmptyEntries); // split line into values based on delimiters
                    var date = DateTime.Parse(values[0], CultureInfo.InvariantCulture); // parse first column as DateTime using InvariantCulture
                    var open = Math.Round(100 * decimal.Parse(values[1], CultureInfo.InvariantCulture)) / 100; // parse and round opening price to two decimals
                    var high = Math.Round(100 * decimal.Parse(values[2], CultureInfo.InvariantCulture)) / 100; // parse and round high price to two decimals
                    var low = Math.Round(100 * decimal.Parse(values[3], CultureInfo.InvariantCulture)) / 100; // parse and round low price to two decimals
                    var close = Math.Round(100 * decimal.Parse(values[4], CultureInfo.InvariantCulture)) / 100; // parse and round closing price to two decimals
                    ulong volume = ulong.Parse(values[5], CultureInfo.InvariantCulture); // parse volume as unsigned long integer
                    candlesticks.Add(new aCandlestick(date, open, high, low, close, volume)); // adds new aCandlestick object with parsed values
                }
            }
            return candlesticks; // return populated list of candlestick data
        }
    }
}