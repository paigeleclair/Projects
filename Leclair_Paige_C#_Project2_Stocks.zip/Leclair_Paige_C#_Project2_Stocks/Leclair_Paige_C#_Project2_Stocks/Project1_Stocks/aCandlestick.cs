﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2_Stocks //All code belongs to Project2_Stocks
{
    /// <summary>
    /// Defines the public class 'aCandlestick' to represent a single candlestick data point. The get and set of each variable.
    /// </summary>
    public class aCandlestick // define the public class 'aCandlestick' to represent a single candlestick data point
    {
        // properties representing the data fields for a candlestick

        public DateTime Date { get; set; } // property for the date of the candlestick. uses DateTime to handle date values
        public decimal Open { get; set; }   // property for the opening price of the asset, stored as a decimal for precision
        public decimal High { get; set; }   // property for the highest price reached during the time period
        public decimal Low { get; set; }    // property for the lowest price reached during the time period
        public decimal Close { get; set; }  // property for the closing price of the asset
        public ulong Volume { get; set; }   // property for the trading volume, using ulong to accommodate large numbers

        /// <summary>
        /// Constructor to initialize a new instance of the aCandlestick class.
        /// </summary>
        /// <param name="date">The date of the candlestick.</param>
        /// <param name="open">The opening price.</param>
        /// <param name="high">The highest price.</param>
        /// <param name="low">The lowest price.</param>
        /// <param name="close">The closing price.</param>
        /// <param name="volume">The volume of stocks traded.</param>
        public aCandlestick(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume)
        {
            Date = date;   // set the Date property to the provided date parameter
            Open = open;   // set the Open property to the provided open price
            High = high;   // set the High property to the provided high price
            Low = low;     // set the Low property to the provided low price
            Close = close; // set the Close property to the provided closing price
            Volume = volume; // set the Volume property to the provided volume of stocks traded
        }

        /// <summary>
        /// Converts to string and returns a string representation of the aCandlestick object.
        /// </summary>
        /// <returns>A formatted string with the candlestick's details.</returns>
        public override string ToString() // override the ToString method to provide a custom string representation of the object
        {
            return $"Date: {Date.ToShortDateString()}, Open: {Open}, High: {High}, Low: {Low}, Close: {Close}, Volume: {Volume}";  // format and return the string with the candlestick details, displaying each property
        }
    }
}