﻿using System.Windows.Forms.DataVisualization.Charting;

namespace Project2_Stocks //All code belongs to Project2_Stocks
{
    partial class Form_Display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.label_startDate = new System.Windows.Forms.Label();
            this.label_endDate = new System.Windows.Forms.Label();
            this.dateTimePicker_startDateDisplay = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_endDateDisplay = new System.Windows.Forms.DateTimePicker();
            this.button_refresh = new System.Windows.Forms.Button();
            this.chart_stockData = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.openFileDialog_stockFile = new System.Windows.Forms.OpenFileDialog();
            this.bindingSource_candlestickData = new System.Windows.Forms.BindingSource(this.components);
            this.hScrollBar1_Margin = new System.Windows.Forms.HScrollBar();
            this.comboBox1_UpWaves = new System.Windows.Forms.ComboBox();
            this.comboBox2_DownWaves = new System.Windows.Forms.ComboBox();
            this.label1_UpWaves = new System.Windows.Forms.Label();
            this.label1_DownWaves = new System.Windows.Forms.Label();
            this.label1_Margin = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1_Margin = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.chart_stockData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource_candlestickData)).BeginInit();
            this.SuspendLayout();
            // 
            // label_startDate
            // 
            this.label_startDate.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_startDate.AutoSize = true;
            this.label_startDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_startDate.Location = new System.Drawing.Point(694, 6);
            this.label_startDate.Name = "label_startDate";
            this.label_startDate.Size = new System.Drawing.Size(60, 15);
            this.label_startDate.TabIndex = 1;
            this.label_startDate.Text = "Start Date:";
            // 
            // label_endDate
            // 
            this.label_endDate.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label_endDate.AutoSize = true;
            this.label_endDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_endDate.Location = new System.Drawing.Point(694, 58);
            this.label_endDate.Name = "label_endDate";
            this.label_endDate.Size = new System.Drawing.Size(57, 15);
            this.label_endDate.TabIndex = 2;
            this.label_endDate.Text = "End Date:";
            // 
            // dateTimePicker_startDateDisplay
            // 
            this.dateTimePicker_startDateDisplay.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.dateTimePicker_startDateDisplay.Location = new System.Drawing.Point(628, 22);
            this.dateTimePicker_startDateDisplay.Name = "dateTimePicker_startDateDisplay";
            this.dateTimePicker_startDateDisplay.Size = new System.Drawing.Size(188, 20);
            this.dateTimePicker_startDateDisplay.TabIndex = 3;
            // 
            // dateTimePicker_endDateDisplay
            // 
            this.dateTimePicker_endDateDisplay.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.dateTimePicker_endDateDisplay.Location = new System.Drawing.Point(628, 75);
            this.dateTimePicker_endDateDisplay.Name = "dateTimePicker_endDateDisplay";
            this.dateTimePicker_endDateDisplay.Size = new System.Drawing.Size(188, 20);
            this.dateTimePicker_endDateDisplay.TabIndex = 4;
            // 
            // button_refresh
            // 
            this.button_refresh.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button_refresh.Location = new System.Drawing.Point(658, 110);
            this.button_refresh.Name = "button_refresh";
            this.button_refresh.Size = new System.Drawing.Size(127, 47);
            this.button_refresh.TabIndex = 5;
            this.button_refresh.Text = "REFRESH";
            this.button_refresh.UseVisualStyleBackColor = true;
            this.button_refresh.Click += new System.EventHandler(this.button_loadData_Click);
            // 
            // chart_stockData
            // 
            this.chart_stockData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea3.Name = "ChartArea_OHLC";
            chartArea4.AlignWithChartArea = "ChartArea_OHLC";
            chartArea4.AxisY.Title = "Volume";
            chartArea4.Name = "ChartArea_Volume";
            this.chart_stockData.ChartAreas.Add(chartArea3);
            this.chart_stockData.ChartAreas.Add(chartArea4);
            this.chart_stockData.Location = new System.Drawing.Point(12, 22);
            this.chart_stockData.Name = "chart_stockData";
            this.chart_stockData.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Chocolate;
            series3.ChartArea = "ChartArea_OHLC";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series3.CustomProperties = "PriceDownColor=Red, PriceUpColor=Lime";
            series3.Legend = "Legend_OHLCV";
            series3.Name = "Series_OHLC";
            series3.XValueMember = "Date";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series3.YValueMembers = "High,Low,Open,Close";
            series3.YValuesPerPoint = 4;
            series4.ChartArea = "ChartArea_Volume";
            series4.Legend = "Legend_OHLCV";
            series4.Name = "Series_Volume";
            series4.XValueMember = "Date";
            series4.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series4.YValueMembers = "Volume";
            this.chart_stockData.Series.Add(series3);
            this.chart_stockData.Series.Add(series4);
            this.chart_stockData.Size = new System.Drawing.Size(594, 450);
            this.chart_stockData.TabIndex = 2;
            this.chart_stockData.Text = "chart1";
            // 
            // openFileDialog_stockFile
            // 
            this.openFileDialog_stockFile.FileName = "openFileDialog1";
            this.openFileDialog_stockFile.InitialDirectory = "C:\\Users\\steph\\OneDrive\\Desktop\\Coding\\C#\\Project1_Stocks\\Stock Data";
            this.openFileDialog_stockFile.Multiselect = true;
            // 
            // hScrollBar1_Margin
            // 
            this.hScrollBar1_Margin.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.hScrollBar1_Margin.LargeChange = 1;
            this.hScrollBar1_Margin.Location = new System.Drawing.Point(664, 307);
            this.hScrollBar1_Margin.Maximum = 4;
            this.hScrollBar1_Margin.Minimum = 1;
            this.hScrollBar1_Margin.Name = "hScrollBar1_Margin";
            this.hScrollBar1_Margin.Size = new System.Drawing.Size(129, 20);
            this.hScrollBar1_Margin.TabIndex = 6;
            this.hScrollBar1_Margin.Value = 1;
            this.hScrollBar1_Margin.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Margin_Scroll);
            // 
            // comboBox1_UpWaves
            // 
            this.comboBox1_UpWaves.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox1_UpWaves.DisplayMember = "none";
            this.comboBox1_UpWaves.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1_UpWaves.FormattingEnabled = true;
            this.comboBox1_UpWaves.Location = new System.Drawing.Point(623, 185);
            this.comboBox1_UpWaves.Name = "comboBox1_UpWaves";
            this.comboBox1_UpWaves.Size = new System.Drawing.Size(95, 21);
            this.comboBox1_UpWaves.TabIndex = 10;
            this.comboBox1_UpWaves.SelectedIndexChanged += new System.EventHandler(this.comboBox1_UpWaves_SelectedIndexChanged);
            // 
            // comboBox2_DownWaves
            // 
            this.comboBox2_DownWaves.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.comboBox2_DownWaves.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2_DownWaves.FormattingEnabled = true;
            this.comboBox2_DownWaves.Location = new System.Drawing.Point(724, 185);
            this.comboBox2_DownWaves.Name = "comboBox2_DownWaves";
            this.comboBox2_DownWaves.Size = new System.Drawing.Size(87, 21);
            this.comboBox2_DownWaves.TabIndex = 11;
            this.comboBox2_DownWaves.SelectedIndexChanged += new System.EventHandler(this.comboBox2_DownWaves_SelectedIndexChanged);
            // 
            // label1_UpWaves
            // 
            this.label1_UpWaves.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1_UpWaves.AutoSize = true;
            this.label1_UpWaves.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1_UpWaves.Location = new System.Drawing.Point(641, 167);
            this.label1_UpWaves.Name = "label1_UpWaves";
            this.label1_UpWaves.Size = new System.Drawing.Size(60, 15);
            this.label1_UpWaves.TabIndex = 12;
            this.label1_UpWaves.Text = "Up Waves";
            // 
            // label1_DownWaves
            // 
            this.label1_DownWaves.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1_DownWaves.AutoSize = true;
            this.label1_DownWaves.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1_DownWaves.Location = new System.Drawing.Point(732, 167);
            this.label1_DownWaves.Name = "label1_DownWaves";
            this.label1_DownWaves.Size = new System.Drawing.Size(74, 15);
            this.label1_DownWaves.TabIndex = 13;
            this.label1_DownWaves.Text = "Down Waves";
            // 
            // label1_Margin
            // 
            this.label1_Margin.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1_Margin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1_Margin.Font = new System.Drawing.Font("Times New Roman", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_Margin.Location = new System.Drawing.Point(641, 271);
            this.label1_Margin.Name = "label1_Margin";
            this.label1_Margin.Size = new System.Drawing.Size(152, 33);
            this.label1_Margin.TabIndex = 14;
            this.label1_Margin.Text = "Peak/Valley Margin:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "label1";
            // 
            // textBox1_Margin
            // 
            this.textBox1_Margin.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.textBox1_Margin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1_Margin.Location = new System.Drawing.Point(641, 307);
            this.textBox1_Margin.Name = "textBox1_Margin";
            this.textBox1_Margin.Size = new System.Drawing.Size(20, 20);
            this.textBox1_Margin.TabIndex = 7;
            // 
            // Form_Display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 484);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label1_Margin);
            this.Controls.Add(this.label1_DownWaves);
            this.Controls.Add(this.label1_UpWaves);
            this.Controls.Add(this.comboBox2_DownWaves);
            this.Controls.Add(this.comboBox1_UpWaves);
            this.Controls.Add(this.textBox1_Margin);
            this.Controls.Add(this.hScrollBar1_Margin);
            this.Controls.Add(this.chart_stockData);
            this.Controls.Add(this.button_refresh);
            this.Controls.Add(this.dateTimePicker_endDateDisplay);
            this.Controls.Add(this.dateTimePicker_startDateDisplay);
            this.Controls.Add(this.label_endDate);
            this.Controls.Add(this.label_startDate);
            this.Name = "Form_Display";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.chart_stockData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource_candlestickData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_startDate;
        private System.Windows.Forms.Label label_endDate;
        public System.Windows.Forms.DateTimePicker dateTimePicker_startDateDisplay;
        public System.Windows.Forms.DateTimePicker dateTimePicker_endDateDisplay;
        private System.Windows.Forms.Button button_refresh;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_stockData;
        private System.Windows.Forms.OpenFileDialog openFileDialog_stockFile;
        private System.Windows.Forms.BindingSource bindingSource_candlestickData;
        private System.Windows.Forms.HScrollBar hScrollBar1_Margin;
        private System.Windows.Forms.ComboBox comboBox1_UpWaves;
        private System.Windows.Forms.ComboBox comboBox2_DownWaves;
        private System.Windows.Forms.Label label1_UpWaves;
        private System.Windows.Forms.Label label1_DownWaves;
        private System.Windows.Forms.Label label1_Margin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1_Margin;
    }
}

