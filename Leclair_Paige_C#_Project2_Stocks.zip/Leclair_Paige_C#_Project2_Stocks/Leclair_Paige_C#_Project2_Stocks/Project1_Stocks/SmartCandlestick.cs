﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project2_Stocks;

namespace Project2_Stocks //All code belongs to Project2_Stocks
{
    public class SmartCandlestick : aCandlestick
    {
        // constructor that calls the base class constructor.
        public SmartCandlestick(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume)
            : base(date, open, high, low, close, volume)
        {
        }

        // property to calculate the range (high - low).
        public decimal Range => High - Low;

        // property to calculate the absolute difference between open and close (body range).
        public decimal BodyRange => Math.Abs(Open - Close);

        // property to determine the higher of open or close.
        public decimal TopPrice => Math.Max(Open, Close);

        // property to determine the lower of open or close.
        public decimal BottomPrice => Math.Min(Open, Close);

        // property to calculate the upper tail (high - top price).
        public decimal UpperTail => High - TopPrice;

        // property to calculate the lower tail (bottom price - low).
        public decimal LowerTail => BottomPrice - Low;

        // method to determine if the candlestick is a peak within a given margin.
        public bool IsPeak(List<SmartCandlestick> allCandlesticks, int index, int margin)
        {
            // check if the index is within the valid range considering the margin.
            if (index < margin || index >= allCandlesticks.Count - margin)
            {
                return false;
            }

            // iterate through the candlesticks before the current index.
            for (int i = index - margin; i < index; i++)
            {
                // if any previous candlestick has a high greater than or equal to the current high, it's not a peak.
                if (allCandlesticks[i].High >= High)
                {
                    return false;
                }
            }

            // iterate through the candlesticks after the current index.
            for (int i = index + 1; i <= index + margin; i++)
            {
                // if any subsequent candlestick has a high greater than or equal to the current high, it's not a peak.
                if (allCandlesticks[i].High >= High)
                {
                    return false;
                }
            }
            // if no higher highs were found within the margin, it's a peak.
            return true;
        }

        // method to determine if the candlestick is a valley within a given margin.
        public bool IsValley(List<SmartCandlestick> allCandlesticks, int index, int margin)
        {
            // check if the index is within the valid range considering the margin.
            if (index < margin || index >= allCandlesticks.Count - margin)
            {
                return false;
            }

            // iterate through the candlesticks before the current index.
            for (int i = index - margin; i < index; i++)
            {
                // if any previous candlestick has a low less than or equal to the current low, it's not a valley.
                if (allCandlesticks[i].Low <= Low)
                {
                    return false;
                }
            }

            // iterate through the candlesticks after the current index.
            for (int i = index + 1; i <= index + margin; i++)
            {
                // if any subsequent candlestick has a low less than or equal to the current low, it's not a valley.
                if (allCandlesticks[i].Low <= Low)
                {
                    return false;
                }
            }
            // if no lower lows were found within the margin, it's a valley.
            return true;
        }

        // override the ToString method to include additional properties.
        public override string ToString()
        {
            return $"{base.ToString()}, Range: {Range}, BodyRange: {BodyRange}, TopPrice: {TopPrice}, BottomPrice: {BottomPrice}";
        }
    }
}